<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "sgpd"; // nome do banco

$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    echo ("Falha na conexão: " . $conn->connect_error);
} else {
    echo "Conexão bem-sucedida!";
}
